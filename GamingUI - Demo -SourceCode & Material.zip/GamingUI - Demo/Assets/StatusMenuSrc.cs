﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class playerStatus
{
    public static int Level = 1;
    public static int ExpAmount = 0;
    public static int NextLevel = 50;
    public static int skillspoint = 0;
    public static int Statuspoint = 10;
    public static int Strength = 10;
    public static int Agility = 10;
    public static int Dexterity = 10;
    public static int Luck = 10;
    public static int Intelligence = 10;
    public static int Inspiration;
    public static int Vitality = 10;
    public static int Sprit = 10;
    public static int HitPoint;
    public static int Mana;


}


[System.Serializable]
public class playercontainer
{
    public static int int1; //playerstatuspoint;
    public static int int2;//playercurrentexp;
    public static int int3;//playerexpcap;
    public static int int4;//playerlevel;
    public static int int6 = 10;//playerstrength;
    public static int int7 = 10;//playeragility;
    public static int int8 = 10;//playerdexterity;
    public static int int9 = 10;//playerluck;
    public static int int10 = 10;//playerintelligence;
    public static int int12 = 10;//playervitality;
    public static int int13 = 10;//playersprite;
    public static int int14 = 160;// playerHP;
    public static int int15 = 50;//playerMana;
}


public class StatusMenuSrc : MonoBehaviour
{
    public static int[,] StatusMenuCaseNumber = new int[7, 9];

    private GameObject Exp;
    private GameObject Expnumber;
    private GameObject ExpAmount;

    private GameObject LVinfo;

    public static int x;
    public static int y;

    private bool crosstheline;
    public static int Applied;

    public static GameObject str;
    public static GameObject agi;

    private GameObject strplus;
    private GameObject agiplus;

    public static GameObject strmins;
    public static GameObject agimins;

    private GameObject submenucursor;
    private GameObject statuspoint;

    private GameObject statusmenutitle;

    public static bool starttesting;

    // Use this for initialization
    void Awake()
    {
       
        Expnumber = GameObject.Find("ExpNumber");
        ExpAmount = GameObject.Find("ExpAmount");

        LVinfo = GameObject.Find("PlayerLV");

        str = GameObject.Find("Strength");
        agi = GameObject.Find("Agility");

        strmins = GameObject.Find("Str-");
        agimins = GameObject.Find("Agi-");
        strplus = GameObject.Find("Str+");
        agiplus = GameObject.Find("Agi+");

        submenucursor = GameObject.Find("SubmenuCursor");
        statuspoint = GameObject.Find("StatusPoint");

        statusmenutitle = GameObject.Find("Name");
    }

    void Start()
    {
        Menu.disableUI(gameObject);
        gameObject.GetComponent<RawImage>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
        //assign value to menu
        str.GetComponent<Text>().text = playerStatus.Strength.ToString();
        agi.GetComponent<Text>().text = playerStatus.Agility.ToString();
        statuspoint.GetComponent<TextMeshProUGUI>().text = "Status Point     " + playerStatus.Statuspoint;
        Expnumber.GetComponent<Text>().text = playerStatus.ExpAmount.ToString() + "/" + playerStatus.NextLevel;
        ExpAmount.GetComponent<RectTransform>().sizeDelta = new Vector2(
        200f * ((float)playerStatus.ExpAmount / playerStatus.NextLevel),
        15f);
        LVinfo.GetComponent<TextMeshProUGUI>().text = "Lv " + playerStatus.Level.ToString();
        if(playerStatus.ExpAmount > playerStatus.NextLevel | playerStatus.ExpAmount == playerStatus.NextLevel)
        { playerStatus.NextLevel = 50 + 50 * (playerStatus.Level - 1) * 5; }
        playerStatus.Level += (int) Mathf.Floor((float)playerStatus.ExpAmount / playerStatus.NextLevel);
        playerStatus.Statuspoint += (int)Mathf.Floor((float)playerStatus.ExpAmount / playerStatus.NextLevel)*10;

        if (starttesting == true)
        {
            playerStatus.ExpAmount += 1;
        }
        if(starttesting == false)
        {
            playerStatus.ExpAmount += 0;
        }

        if (OptionSelection.optiontitle.transform.localPosition == new Vector3(716f, 323f, 0))
        { submenucursor.GetComponent<RawImage>().enabled = true; }
        else { submenucursor.GetComponent<RawImage>().enabled = false; }


        if (statuspoint.GetComponent<TextMeshProUGUI>().text == "Status Point     0" &&
           statusmenutitle.GetComponent<Text>().text != "")
        {
            
            strmins.GetComponent<RawImage>().enabled = false;
            strplus.GetComponent<RawImage>().enabled = false;
            agimins.GetComponent<RawImage>().enabled = false;
            agiplus.GetComponent<RawImage>().enabled = false;
            
            if (Applied == 1)
            {
                for (int t = 1; t < 3; t++)
                { StatusMenuCaseNumber[4, t] = 1; }
            }
        }


        if (OptionSelection.optiontitle.transform.localPosition == new Vector3(716f, 323f, 0) &&
           ((Applied != 2) | statuspoint.GetComponent<TextMeshProUGUI>().text != "Status Point     0"))
        {
            submenucursor.GetComponent<RawImage>().enabled = true;
            if (Input.GetKeyDown("w"))
            {
                if (Applied == 1)
                { crosstheline = false; }

                if (x != 4)
                { y -= 1; }

                if (y < 1)
                {
                    StatusMenuCaseNumber[x, 1] = 0;
                    y = 4;
                }
                StatusMenuCaseNumber[x, y] = 1;
                StatusMenuCaseNumber[x, y + 1] = 0;
            }

            if (Input.GetKeyDown("s"))
            {
                if (Applied == 1)
                { crosstheline = false; }

                if (x != 4)
                { y += 1; }

                if (y > 4)
                {
                    StatusMenuCaseNumber[x, 2] = 0;
                    y = 1;
                }
                StatusMenuCaseNumber[x, y] = 1;
                StatusMenuCaseNumber[x, y - 1] = 0;
            }


            if (Input.GetKeyDown("a"))
            {
                if (Applied == 1)
                {
                    crosstheline = false;
                    x -= 1;
                    if (x < 2)
                    {
                        StatusMenuCaseNumber[2, y] = 0;
                        x = 4;
                    }
                    StatusMenuCaseNumber[x, y] = 1;
                    StatusMenuCaseNumber[x + 1, y] = 0;
                }
                else
                {
                    x -= 2;
                    if (x < 2)
                    {
                        StatusMenuCaseNumber[2, y] = 0;
                        x = 4;
                    }
                    StatusMenuCaseNumber[x, y] = 1;
                    StatusMenuCaseNumber[x + 2, y] = 0;
                }

            }
            if (Input.GetKeyDown("d"))
            {
                if (Applied == 1)
                {
                    crosstheline = true;
                    x += 1;
                    if (x > 4)
                    {
                        StatusMenuCaseNumber[4, y] = 0;
                        x = 2;
                    }
                    StatusMenuCaseNumber[x, y] = 1;
                    StatusMenuCaseNumber[x - 1, y] = 0;
                }
                else
                {
                    x += 2;
                    if (x > 4)
                    {
                        StatusMenuCaseNumber[4, y] = 0;
                        x = 2;
                    }
                    StatusMenuCaseNumber[x, y] = 1;
                    StatusMenuCaseNumber[x - 2, y] = 0;
                }
            }

            //str+
            if (StatusMenuCaseNumber[2, 1] == 1)
            {
                submenucursor.transform.localPosition = new Vector2(-240f, 0f);
                if (Input.GetKeyDown("return"))
                {
                    playerStatus.Statuspoint -= 1;
                    if (playerStatus.Statuspoint < 0)
                    { playerStatus.Statuspoint = 0; }
                    playerStatus.Strength += 1;
                    str.GetComponent<Text>().color = new Color32(0, 255, 0, 255);
                    if (str.GetComponent<Text>().color == new Color32(0, 255, 0, 255))
                    {
                        strmins.GetComponent<RawImage>().enabled = true;
                        Applied = 1;
                    }
                }
            }

            //str-
            if (StatusMenuCaseNumber[3, 1] == 1)
            {
                if (strmins.GetComponent<RawImage>().enabled == true)
                { submenucursor.transform.localPosition = new Vector3(-140f, 0f); }
                else
                {
                    if (crosstheline == false)
                    { x -= 1; }
                    if (crosstheline == true)
                    { x += 1; }
                    StatusMenuCaseNumber[x, y] = 1;
                    StatusMenuCaseNumber[3, 1] = 0;
                }
                if (Input.GetKeyDown("return"))
                {
                    crosstheline = false;
                    playerStatus.Statuspoint += 1;
                    playerStatus.Strength -= 1;
                    if (playerStatus.Strength <= playercontainer.int6)
                    {

                        playerStatus.Strength = playercontainer.int6;
                        str.GetComponent<Text>().color = new Color32(255, 255, 255, 255);
                        strmins.GetComponent<RawImage>().enabled = false;
                    }
                }
            }

            //agi+
            if (StatusMenuCaseNumber[2, 2] == 1)
            {
                submenucursor.transform.localPosition = new Vector3(-240f, -78f, 0);
                if (Input.GetKeyDown("return"))
                {
                    playerStatus.Statuspoint -= 1;
                    if (playerStatus.Statuspoint < 0)
                    { playerStatus.Statuspoint = 0; }
                    playerStatus.Agility += 1;
                    agi.GetComponent<Text>().color = new Color32(0, 255, 0, 255);
                    if (agi.GetComponent<Text>().color == new Color32(0, 255, 0, 255))
                    {
                        agimins.GetComponent<RawImage>().enabled = true;
                        Applied = 1;
                    }
                }
            }

            //agi-
            if (StatusMenuCaseNumber[3, 2] == 1)
            {
                if (agimins.GetComponent<RawImage>().enabled == true)
                { submenucursor.transform.localPosition = new Vector3(-140f, -78f, 0); }
                else
                {
                    if (crosstheline == false)
                    { x -= 1; }
                    if (crosstheline == true)
                    { x += 1; }
                    StatusMenuCaseNumber[x, y] = 1;
                    StatusMenuCaseNumber[3, 2] = 0;
                }
                if (Input.GetKeyDown("return"))
                {
                    crosstheline = false;
                    playerStatus.Statuspoint += 1;
                    playerStatus.Agility -= 1;
                    if (playerStatus.Agility <= playercontainer.int7)
                    {
                        playerStatus.Agility = playercontainer.int7;
                        agi.GetComponent<Text>().color = new Color32(255, 255, 255, 255);
                        agimins.GetComponent<RawImage>().enabled = false;
                    }
                }
            }

            for (int t = 1; t < 5; t++)
            {
                if (StatusMenuCaseNumber[4, t] == 1)
                {

                    submenucursor.transform.localPosition = new Vector3(325f, -220f, 0);
                    if (Input.GetKeyDown("return"))
                    {
                        crosstheline = false;
                        playercontainer.int6 = playerStatus.Strength;
                        playercontainer.int7 = playerStatus.Agility;
                        playercontainer.int1 = playerStatus.Statuspoint;
                        playercontainer.int2 = playerStatus.ExpAmount;
                        playercontainer.int3 = playerStatus.NextLevel;
                        playercontainer.int4 = playerStatus.Level;

                        str.GetComponent<Text>().color = new Color32(255, 255, 255, 255);
                        agi.GetComponent<Text>().color = new Color32(255, 255, 255, 255);
                        Applied = 2;
                        strmins.GetComponent<RawImage>().enabled = false;
                        agimins.GetComponent<RawImage>().enabled = false;

                    }
                }
            }

       
            for (int i = 2; i < 4; i++)
            {
                if (StatusMenuCaseNumber[i, 3] == 1) {
                    submenucursor.transform.localPosition = new Vector3(-290f, -200f, 0);
                    if (Input.GetKeyDown("return"))
                    {
                        starttesting = true;
                    }
                }
            }

            for (int i = 2; i < 4; i++)
            {
                if (StatusMenuCaseNumber[i, 4] == 1)
                {
                    submenucursor.transform.localPosition = new Vector3(-290f, -235f, 0);
                    if (Input.GetKeyDown("return"))
                    {
                        starttesting = false;
                    }
                }

            }

        }

        else if (statuspoint.GetComponent<TextMeshProUGUI>().text == "Status Point     0" && Applied == 2)
        {
            submenucursor.GetComponent<RawImage>().enabled = false;
        }
    }
}
