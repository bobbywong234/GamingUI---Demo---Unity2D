﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OpenUI : MonoBehaviour {

    public static int i;
    private GameObject blackfadein;

    void Awake()
    {
        blackfadein = GameObject.Find("FadeScene");   
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {


        if (blackfadein.GetComponent<RawImage>().color == new Color32(0,0,0,0))
        {
            if (Input.GetKeyDown("escape"))
            {
                i += 1;
                if (i > 1) { i = 0; }
            }
        }
        


    
        switch (i)
        {
            case 0:
                gameObject.GetComponent<Canvas>().enabled = false;
                break;
            case 1:
                gameObject.GetComponent<Canvas>().enabled = true;
                break;
        }

	}
}
