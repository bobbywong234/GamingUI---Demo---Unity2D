﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine.SceneManagement;



public class MainMenuCursor : MonoBehaviour
{
    public static GameObject optionTitle;
    public static GameObject option1;
    public static int i;

    void Awake()
    {
 
    }

    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("a")) {
            i -= 1;
            if (i <= 0) { i = 1; }
        }
        if (Input.GetKeyDown("d")) {
            //setting cap for the last option
            //use switch case to move mainmenucursor and to select different submenu option

            i += 1;
            if(i > 4) { i = 4; }
        }

        switch (i)
        {
            case 1:
                //go to next option position
                //input.getkeydown("return") to do something
                break;
            case 2:
                //go to next option position
                //input.getkeydown("return") to do something
                break;
            case 3:
                //go to next option position
                //input.getkeydown("return") to do something
                break;
            case 4:
                //go to next option position
                //input.getkeydown("return") to do something
                break;
        }
        



        gameObject.transform.eulerAngles += new Vector3(0, 0, 30f * Time.deltaTime);
    }
}
