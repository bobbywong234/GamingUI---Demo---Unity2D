﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Menu
{
    public static void disableUI(GameObject Gameobject)
    {
        foreach (Transform menuitem in Gameobject.transform)
        {
            if (menuitem.GetComponent<RawImage>() != null)
            { menuitem.GetComponent<RawImage>().enabled = false; }
            if (menuitem.GetComponent<Text>() != null)
            { menuitem.GetComponent<Text>().enabled = false; }
            if (menuitem.GetComponent<TextMeshProUGUI>() != null)
            { menuitem.GetComponent<TextMeshProUGUI>().enabled = false; }
            if (menuitem.GetComponent<Image>() != null)
            { menuitem.GetComponent<Image>().enabled = false; }

        }
    }

    public static void enableUI(GameObject Gameobject)
    {
        foreach (Transform menuitem in Gameobject.transform)
        {
            if (menuitem.GetComponent<RawImage>() != null)
            { menuitem.GetComponent<RawImage>().enabled = true; }
            if (menuitem.GetComponent<Text>() != null)
            { menuitem.GetComponent<Text>().enabled = true; }
            if (menuitem.GetComponent<TextMeshProUGUI>() != null)
            { menuitem.GetComponent<TextMeshProUGUI>().enabled = true; }
            if (menuitem.GetComponent<Image>() != null)
            { menuitem.GetComponent<Image>().enabled = true; }

        }
    }

}

public class OptionSelection : MonoBehaviour {

    private GameObject option1;
    public static GameObject optiontitle;
    private GameObject statusmenu;
    private GameObject FadeIn;
    private GameObject GamingUI;

    void Awake()
    {
        GamingUI = GameObject.Find("GamingUI");
        option1 = GameObject.Find("Option1");
        statusmenu = GameObject.Find("StatusMenu");
        FadeIn = GameObject.Find("FadeScene");
        optiontitle = GameObject.Find("OptionTitle");
    }

    // Use this for initialization
    void Start () {
        Menu.disableUI(statusmenu);
        statusmenu.GetComponent<RawImage>().enabled = false;
    }
	
	// Update is called once per frame
	void Update () {

        if (GamingUI.GetComponent<Canvas>().enabled == true)
        {
            if (optiontitle.transform.localPosition == new Vector3(347f, 323f, 0))
            {
                if (Input.GetKeyDown("return"))
                {
                    FadeIn.GetComponent<Animator>().SetBool("FadeIn", true);
                    FadeIn.GetComponent<Animator>().SetBool("FadeOut", false);
                    Menu.enableUI(statusmenu);
                    statusmenu.GetComponent<RawImage>().enabled = true;
                    optiontitle.GetComponent<Animator>().SetBool("PopOut", true);
                    option1.GetComponent<Animator>().SetBool("PopOut", true);
                    StatusMenuSrc.x = 2;
                    StatusMenuSrc.y = 1;
                    StatusMenuSrc.StatusMenuCaseNumber[2, 1] = 1;
                    gameObject.GetComponent<RawImage>().enabled = true;
                    StatusMenuSrc.strmins.GetComponent<RawImage>().enabled = false;
                    StatusMenuSrc.agimins.GetComponent<RawImage>().enabled = false;
                    playercontainer.int1 = playerStatus.Statuspoint;
                    playercontainer.int2 = playerStatus.ExpAmount;
                    playercontainer.int3 = playerStatus.NextLevel;
                    playercontainer.int4 = playerStatus.Level;

                }
            }


            if (optiontitle.transform.localPosition != new Vector3(347f, 323f, 0))
            {
                if (Input.GetKeyDown("escape"))
                {
                    StatusMenuSrc.starttesting = false;
                    playerStatus.Statuspoint = playercontainer.int1;
                    playerStatus.ExpAmount = playercontainer.int2;
                    playerStatus.NextLevel = playercontainer.int3;
                    playerStatus.Level = playercontainer.int4;
                    FadeIn.GetComponent<Animator>().SetBool("FadeOut", true);
                    Menu.disableUI(statusmenu);
                    statusmenu.GetComponent<RawImage>().enabled = false;
                    optiontitle.GetComponent<Animator>().SetBool("PopOut", false);
                    option1.GetComponent<Animator>().SetBool("PopOut", false);
                    if (StatusMenuSrc.Applied == 1)
                    {
                        playerStatus.Strength = playercontainer.int6;
                        playerStatus.Agility = playercontainer.int7;
                        playerStatus.Statuspoint = playercontainer.int1; ;
                        StatusMenuSrc.str.GetComponent<Text>().color = new Color32(255, 255, 255, 255);
                        StatusMenuSrc.agi.GetComponent<Text>().color = new Color32(255, 255, 255, 255);

                    }


                    StatusMenuSrc.Applied = 0;
                    StatusMenuSrc.x = 0;
                    StatusMenuSrc.y = 0;
                    for (int x = 0; x < 7; x++)
                    {
                        for (int y = 0; y < 9; y++)
                        {
                            StatusMenuSrc.StatusMenuCaseNumber[x, y] = 0;
                        }
                    }
                }
            }
        }
        
        if(OpenUI.i == 0)
        {
            optiontitle.GetComponent<Animator>().SetBool("EnterUI", false);
            option1.GetComponent<Animator>().SetBool("EnterUI", false);
        }
        else if(OpenUI.i == 1)
        {
            optiontitle.GetComponent<Animator>().SetBool("EnterUI", true);
            option1.GetComponent<Animator>().SetBool("EnterUI", true);
        }

        if (option1.GetComponent<RectTransform>().localPosition.x == 430f)
        {
            gameObject.GetComponent<RawImage>().enabled = true;
            gameObject.GetComponent<RectTransform>().localPosition =
                option1.GetComponent<RectTransform>().localPosition;

        }
        else
        {
            gameObject.GetComponent<RawImage>().enabled = false;
        }
	}
}
